class urls {
    constructor() {
        this.envUrls = {
            local: 'https://localhost:8443',
            prod: 'http://www.github.com'
        };
    }

    getEnvUrl() { return browser.options.baseUrl; }
   
}
export default new urls();