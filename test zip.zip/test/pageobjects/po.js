import urls from '../utils/urls';
import { expect } from "chai";


class po {
    constructor() {
        this.title = "Base Page";
		this.name = 'btnk';
        
    }
    open(path) {
        browser.url(path);
    }
    launchHomePage() {

        this.open(urls.getEnvUrl());
      
    }
	clickbtn() {
		this.driver.findElement(this.name).then(function(ele){
		ele.click();
		});
		this.driver.sleep(1000);
	} 
}
export default new po();